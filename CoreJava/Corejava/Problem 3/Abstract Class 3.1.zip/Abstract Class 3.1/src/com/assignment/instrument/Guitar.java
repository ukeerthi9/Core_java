package com.assignment.instrument;

public class Guitar extends Instrument{

	@Override
	public void play() {
		// TODO Auto-generated method stub
	System.out.println("guitar is playing.");	
	}

}
