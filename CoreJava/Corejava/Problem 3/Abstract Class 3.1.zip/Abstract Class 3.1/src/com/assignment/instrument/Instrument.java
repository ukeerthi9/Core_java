package com.assignment.instrument;

public abstract class Instrument {
	public abstract void play();
}
