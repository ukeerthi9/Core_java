package com.assignment;

import java.util.Vector;
public class TestEmployeeCollection {
	public static void main(String[] args) {
		
		Vector<Employee> v=new Vector<Employee>();
		Employee e1=new Employee (101,"bhavani", "Mallethula");
		Employee e2=new Employee (102,"srlekha", "kakani");
		Employee e3=new Employee (103,"akanksha", "pasikanti");
		
		v.add(e1);
		v.add(e2);
		v.add(e3);
		display(v);
		
	}
	public static void display(Vector<Employee> v) {
		for(Employee e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEname()+" "+e.getAddress());
		}
	}
}
