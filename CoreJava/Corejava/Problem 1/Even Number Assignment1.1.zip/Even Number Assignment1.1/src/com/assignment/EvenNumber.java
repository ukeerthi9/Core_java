package com.assignment;

import java.util.Scanner;

public class EvenNumber {
	  public static void main(String args[]) {

		  Scanner sc = new Scanner(System.in);
		  System.out.println("Please enter the n value : ");
		  
		  int n = sc.nextInt();

		  for (int i = 1; i <= n; i++) {

		   if (i % 2 == 0) {

		  System.out.print(i + " ");

		   }

		 }
	 }
}


// OUTPUT

// Please enter the n value : 
// 23
// 2 4 6 8 10 12 14 16 18 20 22 
