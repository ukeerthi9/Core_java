import java.util.Scanner;

public class RectangleAttribute {
	    int length; 
	    int width; 
	    int area; 
	    int perimeter;
	    
	    public int getLength() {
			return length;
		}

		public void setLength(int length) {
			this.length = length;
		}

		public int getWidth() {
			return width;
		}

		public void setWidth(int width) {
			this.width = width;
		}

		
	    public RectangleAttribute()
	    {
	    	length = 1;
	    	width= 1;
	    }

	    void input() {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter length of rectangle: ");
	        length = in.nextInt();
	        System.out.print("Enter width of rectangle: ");
	        width = in.nextInt();
	    }
	    
	    void  areaRectangle()
	    {
	        area = length * width;
	        //System.out.println("Area of Rectangle= "+area);
	       
	    }
	 
	     void  perimeterRectangle()
	    {
	    	 perimeter = 2*(length + width);
	    	//System.out.println("Perimeter of Rectangle= "+perimeter);
	    }

	    void display() {
	    	if(length>0 && length<20)
	        {
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Parameter of Rectangle = " +perimeter);}
	       
	        }

	    public static void main(String args[]) {
	    	
	    	RectangleAttribute obj1 = new RectangleAttribute();
	        obj1.input();
	        obj1.areaRectangle();
	        obj1.perimeterRectangle();
	        obj1.display();
	        
	        System.out.println("****************************");
	        
	        RectangleAttribute obj2 = new RectangleAttribute();
	        obj2.input();
	        obj2.areaRectangle();
	        obj2.perimeterRectangle();
	        obj2.display();
	        
	        System.out.println("****************************");
	        
	        RectangleAttribute obj3 = new RectangleAttribute();
	        obj3.input();
	        obj3.areaRectangle();
	        obj3.perimeterRectangle();
	        obj3.display();
	        
	        System.out.println("****************************");
	        
	        RectangleAttribute obj4 = new RectangleAttribute();
	        obj4.input();
	        obj4.areaRectangle();
	        obj4.perimeterRectangle();
	        obj4.display();
	        
	        System.out.println("****************************");
	        
	        RectangleAttribute obj5 = new RectangleAttribute();
	        obj5.input();
	        obj5.areaRectangle();
	        obj5.perimeterRectangle();
	        obj5.display();
	    	
	    }
}
