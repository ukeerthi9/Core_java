import java.util.Scanner;

public class Fibonaci {
	 public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter your start number: ");
		    int i =sc.nextInt(), n = 13, firstTerm = i;
		    System.out.println("Enter second number: ");
		    int secondTerm =sc.nextInt();
		    System.out.println("Fibonacci Series till " + n + " terms:");

		    while (i <= n) {
		      System.out.print(firstTerm + " " );

		      int nextTerm = firstTerm + secondTerm;
		      firstTerm = secondTerm;
		      secondTerm = nextTerm;

		      i++;
		    }
		  }

}
