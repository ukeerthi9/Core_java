
public class IntegerArray {
	  public static void main(String[] args) {  
		  int arr[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
	        int sum = 0;  
	       
	        for (int i = 0; i <=14; i++) {  
	           sum = sum + arr[i];  
	        }  
	        arr[15]=sum;
	        System.out.print("a: Sum of first 14th elements and stored it at 15th index of arr= "); 
	        for (int element:arr)    
	        System.out.print(element+" ");
	        int sum1=0;
	        int div=1;
	        for (int i = 0; i < arr.length; i++) {  
	            sum1 = sum1+ arr[i]; 
	            div=sum1/arr.length;
	         } 
	        arr[16]=div;
	        System.out.print("\nb: the average of all numbers and stored it at element 16 = ");
	        for (int element:arr)    
	            System.out.print(element+" ");
	        int small = arr[0];
	        for(int i=0; i<arr.length; i++)
	        {
	           if(small>arr[i])
	              small = arr[i];
	        }
	        System.out.print("\nc: the smallest value from the array and stored it at element 17 = ");
	        arr[17]=small;
	        for (int element:arr)    
	            System.out.print(element+" ");
	    }  

}
