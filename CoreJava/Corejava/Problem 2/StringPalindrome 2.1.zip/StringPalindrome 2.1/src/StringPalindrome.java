import java.util.Scanner;

public class StringPalindrome {
	  public static void main(String args[])
	   {
	      String str, rev = "";
	      Scanner sc = new Scanner(System.in);
	 
	      System.out.println("Enter a string:");
	      str = sc.nextLine();
	      String Strupper=str.toUpperCase();
	      int length = Strupper.length();
	 
	      for ( int i = length - 1; i >= 0; i-- )
	         rev = rev + Strupper.charAt(i);
	 
	      if (Strupper.equals(rev))
	         System.out.println(Strupper+" is a palindrome.");
	      else
	         System.out.println(Strupper+" is not a palindrome.");
	 
	   }

}
